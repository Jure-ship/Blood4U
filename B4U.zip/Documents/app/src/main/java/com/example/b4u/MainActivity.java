package com.example.b4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button animacija;
    ImageView redcircle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        animacija = findViewById(R.id.animacija);
        redcircle = findViewById(R.id.redcircle);



        
        animacija.setVisibility(View.INVISIBLE);
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CountDownTimer(3000, 34) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        ViewGroup.LayoutParams params = redcircle.getLayoutParams();
                        if (params.width <= 0) {
                            params.width = 200;
                            params.height = 100;
                        } else {
                            if (v.getId() == R.id.animacija) {
                                params.width *= 1.1;
                                params.height *= 1.1;
                            }

                        }
                        redcircle.setLayoutParams(params);
                    }

                    @Override
                    public void onFinish() {

                    }
                }.start();
            }
        };
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                redcircle.setVisibility(View.INVISIBLE);
            }
        },0);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                redcircle.setVisibility(View.VISIBLE);
            }
        },2200);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                animacija.performClick();
            }
        },2240);

        animacija.setOnClickListener(listener);
        NextActivity();

    }
    public void NextActivity()
    {
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {

                Intent mainIntent = new Intent(MainActivity.this,all_phone1.class);
                MainActivity.this.startActivity(mainIntent);
                MainActivity.this.finish();
            }
        }, 5000);

    }
}