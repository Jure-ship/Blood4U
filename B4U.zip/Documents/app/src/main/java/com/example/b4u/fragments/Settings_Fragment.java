package com.example.b4u.fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.b4u.LogIn;
import com.example.b4u.R;
import com.example.b4u.qrscan_open;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;


public class Settings_Fragment extends Fragment {
    private Button logout, past, qrscan;
    TextView izlaz;
    Context context;
    Fragment fragment;
    View view;
    public Settings_Fragment() {

    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_settings_, container, false);

        logout = (Button) view.findViewById(R.id.odjava);
        izlaz=(TextView)view.findViewById(R.id.ime);
        past = (Button) view.findViewById(R.id.povijest);
        qrscan = (Button) view.findViewById(R.id.buttonqr);


        past.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(getContext());
                bottomSheetDialog.setContentView(R.layout.pop_out_table);
                bottomSheetDialog.setCanceledOnTouchOutside(false);

                TableLayout tableLayout = bottomSheetDialog.findViewById(R.id.table_layout);
                Button zatvori = bottomSheetDialog.findViewById(R.id.zatvori_btn);

                zatvori.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        bottomSheetDialog.dismiss();
                    }
                });
                bottomSheetDialog.show();
            }

        });


        qrscan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                escaner();
            }
        });


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), LogIn.class);
                startActivity(i);
                ((Activity) getActivity()).overridePendingTransition(0, 0);
            }
        });


        return view;
    }
    public void escaner() {
        IntentIntegrator intentIntegrator = IntentIntegrator.forSupportFragment(Settings_Fragment.this);
        intentIntegrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);

        //promt text
        intentIntegrator.setPrompt("For flash use volume key up");
        //set bep
        intentIntegrator.setBeepEnabled(true);
        //locked orientaion
        intentIntegrator.setOrientationLocked(true);
        //set capture fragement
        intentIntegrator.setCaptureActivity(Capture.class);
        //initiate  scan
        intentIntegrator.initiateScan();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        //chech condition
        if (result != null) {
            if (result.getContents()==null) {
//when result content is not null
                Toast.makeText(getContext(),"Uspješno skenirano",Toast.LENGTH_SHORT).show();
                //show alert dialog
            }
            else {
                Toast.makeText(getContext(),result.getContents().toString(),Toast.LENGTH_LONG).show();
                Intent intent4 = new Intent(getActivity(), qrscan_open.class);
                startActivity(intent4);
            }
/*


*/
        }
        else {
            //when result content is null
           Toast.makeText(getActivity(),"OOOPS... You did something wrond",Toast.LENGTH_SHORT).show();
            super.onActivityResult(requestCode,resultCode,data);
        }
    }
}
