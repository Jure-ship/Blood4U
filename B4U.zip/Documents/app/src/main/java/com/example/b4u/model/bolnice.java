package com.example.b4u.model;

public class bolnice {
    private String nazivbolnice;
    private int količinaKrvi;
    private int drawableresource;
    private String otvorenobol;

    public bolnice() {
    }

    public bolnice(String nazivbolnice, int količinaKrvi, int drawableresource,String otvorenobol) {
        this.nazivbolnice = nazivbolnice;
        this.količinaKrvi = količinaKrvi;
        this.drawableresource = drawableresource;
        this.otvorenobol=otvorenobol;
    }
    //getter
    public String getNazivbolnice() {
        return nazivbolnice;
    }

    public int getKoličinaKrvi() {
        return količinaKrvi;
    }

    public int getDrawableresource() {
        return drawableresource;
    }

    public String getOtvorenobol() {
        return otvorenobol;
    }

    //setter


    public void setNazivbolnice(String nazivbolnice) {
        this.nazivbolnice = nazivbolnice;
    }

    public void setKoličinaKrvi_0(int količinaKrvi_0) {
        this.količinaKrvi = količinaKrvi_0;
    }

    public void setDrawableresource(int drawableresource) {
        this.drawableresource = drawableresource;
    }

    public void setOtvorenobol(String otvorenobol) {
        this.otvorenobol = otvorenobol;
    }

    public bolnice(int drawableresource, String nazivbolnice, int količinaKrvi_0,String otvorenobol) {
        this.nazivbolnice = nazivbolnice;
        this.količinaKrvi = količinaKrvi_0;
        this.drawableresource=drawableresource;
        this.otvorenobol=otvorenobol;



    }
}
