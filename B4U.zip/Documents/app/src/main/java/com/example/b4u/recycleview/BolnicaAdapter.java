package com.example.b4u.recycleview;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.example.b4u.MainActivity;
import com.example.b4u.R;
import com.example.b4u.all_phone1;
import com.example.b4u.daruj_krv;
import com.example.b4u.daruj_krv_obrada;
import com.example.b4u.guest_activty;
import com.example.b4u.fragments.Home_map_Fragment;
import com.example.b4u.model.bolnice;
import com.example.b4u.qrscan_open;

import java.util.List;

public class BolnicaAdapter extends RecyclerView.Adapter<BolnicaAdapter.bolniceviewholder> {

    Context mContent;
    List<bolnice> mdata;
    Dialog myDialog;
    Dialog myDialog1;


    public BolnicaAdapter(Context mContent,List<bolnice> mdata)
    {
        this.mContent=mContent;
        this.mdata = mdata;
    }

    @NonNull
    @Override
    public bolniceviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        view= LayoutInflater.from(mContent).inflate(R.layout.bolnice_data,parent,false);
        bolniceviewholder vBolnice=new bolniceviewholder(view);

        myDialog=new Dialog(mContent);
        myDialog.setContentView(R.layout.popout_meni_bolnice);


        Window window = myDialog.getWindow();
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

       // Window window1 = myDialog1.getWindow();
      //  window1.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        Button darujkrv_btn=(Button)myDialog.findViewById(R.id.darujkrv_btn);

        darujkrv_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent12 = new Intent(mContent, daruj_krv_obrada.class);
                mContent.startActivity(intent12);
            }
        });


        vBolnice.menu_popout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView dialog_lokacija_tv = (TextView) myDialog.findViewById(R.id.dialog_lokacija_id);
                TextView dialog_otvoreno_tv = (TextView) myDialog.findViewById(R.id.dialog_otvoreno_id);
                TextView dialog_krvnagrupa_tv = (TextView) myDialog.findViewById(R.id.dialog_krvgrupe_id);
                TextView dialog_liotrekrva_tv = (TextView) myDialog.findViewById(R.id.dialog_litrekrv_id);
                ImageView img_bolnice_img=(ImageView)myDialog.findViewById(R.id.imgbolnica);
                ImageView cancel_dialog=(ImageView)myDialog.findViewById(R.id.close_data);


                dialog_lokacija_tv.setText(mdata.get(vBolnice.getAdapterPosition()).getNazivbolnice());
                dialog_liotrekrva_tv.setText(String.valueOf(mdata.get(vBolnice.getAdapterPosition()).getKoličinaKrvi()));
                dialog_otvoreno_tv.setText("9:00 - 21:00");
                dialog_krvnagrupa_tv.setText("A, A+, B, AB");
                img_bolnice_img.setImageResource(mdata.get(vBolnice.getAdapterPosition()).getDrawableresource());


                /*darujkrv_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FragmentManager fm=get

                    }
                });*/

                cancel_dialog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDialog.dismiss();
                    }
                });
                myDialog.show();
            }
        });
        return vBolnice;
    }

    @Override
    public void onBindViewHolder(@NonNull bolniceviewholder holder, int position) {
//https://www.youtube.com/watch?v=T_QfRU-A3s4&t=1193s
        holder.nazivbolniceTV.setText(mdata.get(position).getNazivbolnice());
        holder.KolicinakrviTV.setText(String.valueOf(mdata.get(position).getKoličinaKrvi()));
        holder.imgBolnice.setImageResource(mdata.get(position).getDrawableresource());
        holder.otvorenaBol.setText(mdata.get(position).getOtvorenobol());

        //bind bolnica data here
       /* Glide.with(holder.itemView.getContext()).load(mdata.get(position).getDrawableresource()).
                transform(new CenterCrop(),new RoundedCorners(16))
                .into(holder.imgBolnice); //destinacija */

    }

    @Override
    public int getItemCount() {

        return mdata.size();
    }

    public static class bolniceviewholder extends RecyclerView.ViewHolder {
        private ConstraintLayout menu_popout;
        private ImageView imgBolnice;
        private TextView nazivbolniceTV;
        private TextView KolicinakrviTV;
        private TextView otvorenaBol;

        public bolniceviewholder(@NonNull View itemView) {
            super(itemView);
            menu_popout=(ConstraintLayout) itemView.findViewById(R.id.bolnice_item_id);
            imgBolnice=(ImageView) itemView.findViewById(R.id.bolnica1);
            nazivbolniceTV=(TextView) itemView.findViewById(R.id.nazivbol);
            KolicinakrviTV=(TextView) itemView.findViewById(R.id.kolicinakrv);
            otvorenaBol=(TextView) itemView.findViewById(R.id.otvorenostbol);
        }
    }
}
