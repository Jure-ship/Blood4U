package com.example.b4u;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.vishnusivadas.advanced_httpurlconnection.PutData;

public class LogIn extends AppCompatActivity   {
    EditText ete_mail,etpassword;
    Button prijava1,guset_btn,registracija_btn;
    ProgressBar progresbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in__sign_up);

        ete_mail = findViewById(R.id.e_mail);
        etpassword = findViewById(R.id.password);
        prijava1 = findViewById(R.id.prijava);
        guset_btn = findViewById(R.id.guest);
        registracija_btn = findViewById(R.id.registracija);
        progresbar=findViewById(R.id.progressbar);

        prijava1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username,password;
                username=String.valueOf(ete_mail.getText());
                password=String.valueOf(etpassword.getText());


                if (!username.equals("")&& !password.equals("")) {

                    //Start ProgressBar first (Set visibility VISIBLE)
                    Handler handler = new Handler();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //Starting Write and Read data with URL
                            //Creating array for parameters
                            String[] field = new String[2];
                            field[0] = "username";
                            field[1] = "password";
                            //Creating array for data
                            String[] data = new String[2];
                            data[0] = username;
                            data[1] = password;
                            PutData putData = new PutData("http://192.168.1.8/LoginRegister/login.php?_ijt=idvulnk8k85kvaatscn5ebc8aj", "POST", field, data);
                            if (putData.startPut()) {
                                if (putData.onComplete()) {

                                    String result = putData.getResult();
                                    if (result.equals("Login Success")) {
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();

                                        Intent intent=new Intent(getApplicationContext(), all_phone1.class);
                                        startActivity(intent);

                                    }
                                    //End ProgressBar (Set visibility to GONE)
                                }
                            }
                            //End Write and Read data with URL
                        }
                    });
                }
                else {
                    Toast.makeText(getApplicationContext(),"All fields are required!",Toast.LENGTH_SHORT).show();
                }
            }
        });



        guset_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder1=new AlertDialog.Builder(LogIn.this);
                builder1.setCancelable(true);
                builder1.setTitle("NAPOMENA!");
                builder1.setMessage("Kod guest rada imati ćete ograničene uporabe!");
                builder1.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();

                                Intent i1 = new Intent(getApplicationContext(),guest_activty.class);
                                startActivity(i1);
                            }
                });
                builder1.show();
            }
        });
        registracija_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(getApplicationContext(), Signup.class);
                startActivity(i2);
            }
        });
    }


}