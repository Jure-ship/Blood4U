package com.example.b4u;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.bumptech.glide.disklrucache.DiskLruCache;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import android.renderscript.Sampler;
import android.view.View;
import android.widget.Button;


public class donacija_order extends AppCompatActivity {

    Button btnzat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_donacija_order);



        btnzat=findViewById(R.id.zatvori_act);

        btnzat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                // Intent intent8=new Intent(donacija_order.this, .class);
                //startActivity(intent8);
            }
        });
    }
}
