package com.example.b4u.fragments;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Capture extends CaptureActivity {
}
