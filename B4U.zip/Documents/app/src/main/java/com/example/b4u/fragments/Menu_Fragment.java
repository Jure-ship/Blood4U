package com.example.b4u.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.b4u.R;
import com.example.b4u.model.bolnice;
import com.example.b4u.recycleview.BolnicaAdapter;

import java.util.ArrayList;
import java.util.List;


public class Menu_Fragment extends Fragment {
    View view;
    private RecyclerView rvmojeBolnice;
    private List<bolnice> rcbolnice;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_menu_,container,false);

        rvmojeBolnice =(RecyclerView) view.findViewById(R.id.recyclemenu);
        BolnicaAdapter bolnicaAdapter = new BolnicaAdapter(getContext(),rcbolnice);
        rvmojeBolnice.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvmojeBolnice.setAdapter(bolnicaAdapter);
        // https://www.youtube.com/watch?v=netKwSR4MzA - 13 min
        //https://www.youtube.com/watch?v=Mr9uNodQZ-w - za dns

    return view;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        rcbolnice=new ArrayList<>();
        rcbolnice.add(new bolnice(R.drawable.bolnica_krizine,"Državna bolnica Krizine",55 ,"Otvoreno: 9:00 - 21:00"));
        rcbolnice.add(new bolnice(R.drawable.bolnica_firule,"Državna bolnica Firule",45,"Otvoreno: 9:00 - 21:00" ));
        rcbolnice.add(new bolnice(R.drawable.ambulantamertoajk,"Ambulanta mertojak",23,"Otvoreno: 9:00 - 21:00" ));
        rcbolnice.add(new bolnice(R.drawable.domzdravlja,"Dom zdravlja Split",14,"Otvoreno: 9:00 - 17:00" ));
        rcbolnice.add(new bolnice(R.drawable.dom_zdrvlj,"Dom zdravlja",2,"Otvoreno: 9:00 - 15:00" ));



    }




}