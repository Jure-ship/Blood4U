package com.example.b4u.fragments;

import android.Manifest;
import android.app.ActionBar;
import android.app.Dialog;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.b4u.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import android.app.FragmentTransaction;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.Timer;
import java.util.TimerTask;


public class Home_map_Fragment extends Fragment  {

    private GoogleMap mMap;
    ImageView zatvori1;
    View view;
    int counter=0,counter1=0;
    private ProgressBar prb;
    Context context;
    private static final String TAG = "Home_map_Fragment";
    private Marker krizine;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home_map_, container, false);
//ovdje nešto ne valja
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.google_map);

        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(getContext());
        bottomSheetDialog.setContentView(R.layout.pop_out_map_krizine);
        bottomSheetDialog.setCanceledOnTouchOutside(false);




        prb=(ProgressBar)view.findViewById(R.id.pogbar);
        zatvori1=(ImageView) view.findViewById(R.id.zatv);


        /* final Timer t=new Timer();
        TimerTask tt= new TimerTask() {
            @Override
            public void run() {
                counter=50;
                prb.setProgress(counter);

            }
        };
        t.schedule(tt,0,100);

        TimerTask tt1=new TimerTask() {
            @Override
            public void run() {
                counter--;
                prb.setProgress(counter);

            }
        };
        t.schedule(tt1,0,70);
    */


       /* zatvori1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        }); */
        mapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                mMap = googleMap;

                // Obtain the SupportMapFragment and get notified when the map is ready to be used.

                // Add a marker in Sydney and move the camera
                LatLng splitkrizine = new LatLng(43.50555555555555, 16.467777777777776);
                LatLng splitfirule = new LatLng(43.503907480924696, 16.457793740200945);
                LatLng ambulantamertoajk=new LatLng(43.509255312996856, 16.476947953977742);

                mMap.addMarker(new MarkerOptions().position(splitkrizine).title("Ovo je bolnica krizine"));

                krizine = mMap.addMarker(new MarkerOptions().position(splitfirule).title("Ovo je bolnica Firulee"));

                mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                    @Override
                    public void onMapClick(@NonNull LatLng latLng) {
                        bottomSheetDialog.show();
                    }
                });

                mMap.addMarker((new MarkerOptions().position(ambulantamertoajk).title("Ambulanta Mertoajk")));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(splitfirule, 15));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(splitkrizine, 15));
               /* mMap.setOnInfoWindowClickListener((GoogleMap.OnInfoWindowClickListener) this); */
            }
        });
        return view;
    }

}




