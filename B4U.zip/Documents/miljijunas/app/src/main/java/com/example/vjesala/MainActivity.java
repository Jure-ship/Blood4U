package com.example.vjesala;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button prviodg;
    Button drugiodg;
    Button treciodg;
    Button cetvrtiodg;
    TextView br_pitanja;
    TextView pitanje;
    TextView pare;
    Button iducepitanje;
    Button polapola;
    Button zovi_pom;

    int broj_pitanja = 1;
    int broj3 = 0;
    int novac = 100;
    int broj4 = 1;
    int tocanodg = 0;
    int res, res2, res3, res4 = 0;
    int res5,res6,res7,res8=0;
    double broj5=0.0;
    int broj6=0;
    int tocanodg2=0;
    int zovipri;

    char[] operacije = {'+', '-', '*', '/'};



    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prviodg = findViewById(R.id.btn_za_prviodg);
        drugiodg = findViewById(R.id.btn_za_drugiodg);
        treciodg = findViewById(R.id.btn_za_treciodg);
        cetvrtiodg = findViewById(R.id.btn_za_cetvrtiodg);
        br_pitanja = findViewById(R.id.broj_pitanja);
        pitanje = findViewById(R.id.pitanja);
        pare = findViewById(R.id.novac);
        polapola=findViewById(R.id.polapola);
        iducepitanje = findViewById(R.id.iducepitanj);
        zovi_pom=findViewById(R.id.zovni_pri);

        igra();
    }

    @SuppressLint("SetTextI18n")
    public void iducpit() {
        iducepitanje.setOnClickListener(v ->
                igra()
        );
    }

    public void pola() {        //joker
        polapola.setOnClickListener(v -> {
            if (res == tocanodg) {
                drugiodg.setVisibility(View.GONE);
                treciodg.setVisibility(View.GONE);
            }
            if (res2 == tocanodg) {
                prviodg.setVisibility(View.GONE);
                treciodg.setVisibility(View.GONE);
            }
            if (res3 == tocanodg) {
                drugiodg.setVisibility(View.GONE);
                cetvrtiodg.setVisibility(View.GONE);
            }
            if (res4 == tocanodg) {
                drugiodg.setVisibility(View.GONE);
                prviodg.setVisibility(View.GONE);
            }
            if (res5 == tocanodg) {
                drugiodg.setVisibility(View.GONE);
                cetvrtiodg.setVisibility(View.GONE);
            }
            if (res6 == tocanodg) {
                prviodg.setVisibility(View.GONE);
                cetvrtiodg.setVisibility(View.GONE);
            }
            if (res7 == tocanodg) {
                drugiodg.setVisibility(View.GONE);
                cetvrtiodg.setVisibility(View.GONE);
            }
            if (res8 == tocanodg) {
                drugiodg.setVisibility(View.GONE);
                treciodg.setVisibility(View.GONE);
            }
            polapola.setEnabled(false);
            polapola.setVisibility(View.GONE);
        });
    }
    public void zovni_prij() {      //joker
        zovi_pom.setOnClickListener(v -> {
        zovipri = (int)(Math.random()*5);   //zovi prijatelja, 80% sanse da bude tocno
        int[] rj_bliz = { 1, 2, -1};
        int dodatak=rj_bliz[(int) (Math.random()*rj_bliz.length)];
    if (zovipri<=3) {
        Toast.makeText(getApplicationContext(), "Ja mislim da je točan odgovor " + tocanodg+"!", Toast.LENGTH_SHORT).show();
    }
    else if(zovipri==4) {
        Toast.makeText(getApplicationContext(), "Ja mislim da je točan odgovor " + (tocanodg+dodatak)+"!", Toast.LENGTH_SHORT).show();
    }
    zovi_pom.setEnabled(false);
    zovi_pom.setVisibility(View.GONE);
        });

    }

    @SuppressLint("SetTextI18n")
    public void endGame(int a) {

        switch (a) {
            case 0: // Pogrešan odgovor
                break;
            case 1:
                if (broj_pitanja == 15)
                    pitanje.setText("Vi ste milijunaš!!!");
                break;
        }
    }

    @SuppressLint("SetTextI18n")
    public void igra() {

            Integer[] rjesenja = {0, 1, 2, 3};  //random rjesenja
            List<Integer> intList = Arrays.asList(rjesenja);
            Collections.shuffle(intList);
            intList.toArray(rjesenja);

            Integer[] rj_bliz = {0, 1, 2, -1};  //random rjesenja
            List<Integer> intList1 = Arrays.asList(rjesenja);
            Collections.shuffle(intList1);
            intList1.toArray(rjesenja);

        char[] operacije2 = {'%', 'p', 'k', '2'};
        char tocna_op2 = operacije2[(int) (Math.random() * operacije2.length)];
        String tocna_operacija = "";

        Integer[] rjesenja1 = {0, 1, 2, 3};
        List<Integer> intList2 = Arrays.asList(rjesenja1);
        Collections.shuffle(intList2);
        intList2.toArray(rjesenja1);

            br_pitanja.setText("Sada ste na " + broj_pitanja + " pitanju!");
        if (broj_pitanja <= 5) {
            char tocna_op = operacije[(int) (Math.random() * operacije.length)];

            //generiranje rjsenja
            broj3 = (int) (Math.random() * 28);
            broj4 = (int) (Math.random() * 12 + 1);
            if (tocna_op == '+') {
                tocanodg = broj3 + broj4;
            } else if (tocna_op == '-') {
                tocanodg = broj3 - broj4;
            } else if (tocna_op == '*') {
                tocanodg = broj3 * broj4;
            } else {
                tocanodg = broj3 / broj4;
            }

            if (broj_pitanja == 1) {
                novac = 100;
            }
            if (broj_pitanja == 2) {
                novac = 200;
            }
            if (broj_pitanja == 3) {
                novac = 500;
            }
            if (broj_pitanja == 4) {
                novac = 1000;
            }
            polapola.setBackgroundColor(Color.parseColor("#6666FF"));
            zovi_pom.setBackgroundColor(Color.parseColor("#6666FF"));
            prviodg.setBackgroundColor(Color.parseColor("#6666FF"));
            drugiodg.setBackgroundColor(Color.parseColor("#6666FF"));
            treciodg.setBackgroundColor(Color.parseColor("#6666FF"));
            cetvrtiodg.setBackgroundColor(Color.parseColor("#6666FF"));

            pitanje.setText("Koliko je " + broj3 + tocna_op + broj4+"?");
            //ponudivanje odgovora
            prviodg.setText(String.valueOf((tocanodg + rj_bliz[rjesenja[0]])));
            drugiodg.setText(String.valueOf((tocanodg + rj_bliz[rjesenja[1]])));
            treciodg.setText(String.valueOf((tocanodg + rj_bliz[rjesenja[2]])));
            cetvrtiodg.setText(String.valueOf((tocanodg + rj_bliz[rjesenja[3]])));

            iducepitanje.setVisibility(View.INVISIBLE);

            prviodg.setVisibility(View.VISIBLE);
            drugiodg.setVisibility(View.VISIBLE);
            treciodg.setVisibility(View.VISIBLE);
            cetvrtiodg.setVisibility(View.VISIBLE);

            pola(); // pola pola odgovori
            zovni_prij();   //joker zvanja

            res = Integer.parseInt(prviodg.getText().toString());
            prviodg.setOnClickListener(v -> {   //ako je u prvom botunu odg
                if (tocna_op == '+') {
                    if (res == broj3 + broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        prviodg.setBackgroundColor(Color.GREEN);
                        iducpit();

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '-') {
                    if (res == broj3 - broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        prviodg.setBackgroundColor(Color.GREEN);
                        iducpit();

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '*') {
                    if (res == broj3 * broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        prviodg.setBackgroundColor(Color.GREEN);
                        iducpit();//dalje pitanje

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0); //gotovo
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '/') {
                    if (res == (broj3 / broj4)) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        prviodg.setBackgroundColor(Color.GREEN);
                        iducpit();

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
            });
            res2 = Integer.parseInt(drugiodg.getText().toString());
            drugiodg.setOnClickListener(v -> {  //ako je u drugom botunu odg
                if (tocna_op == '+') {
                    if (res2 == broj3 + broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        drugiodg.setBackgroundColor(Color.GREEN);
                        iducpit();

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '-') {
                    if (res2 == broj3 - broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        drugiodg.setBackgroundColor(Color.GREEN);
                        iducpit();

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '*') {
                    if (res2 == broj3 * broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        drugiodg.setBackgroundColor(Color.GREEN);
                        iducpit();//dalje pitanje

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0); //gotovo
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '/') {
                    if (res2 == broj3 / broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        drugiodg.setBackgroundColor(Color.GREEN);
                        iducpit();

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
            });
            res3 = Integer.parseInt((treciodg.getText().toString()));
            treciodg.setOnClickListener(v -> { //ako je u trecem botunu odg
                if (tocna_op == '+') {
                    if (res3 == broj3 + broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        treciodg.setBackgroundColor(Color.GREEN);
                        iducpit();

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '-') {
                    if (res3 == broj3 - broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        treciodg.setBackgroundColor(Color.GREEN);
                        iducpit();//dalje pitanje

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0); //gotovo
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '*') {
                    if (res3 == broj3 * broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        treciodg.setBackgroundColor(Color.GREEN);
                        iducpit();//dalje pitanje

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '/') {
                    if (res3 == broj3 / broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        treciodg.setBackgroundColor(Color.GREEN);
                        iducpit();

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
            });
            res4 = Integer.parseInt(cetvrtiodg.getText().toString());
            cetvrtiodg.setOnClickListener(v -> { //ako je u cetvrtom botunu odg
                if (tocna_op == '+') {
                    if (res4 == broj3 + broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        cetvrtiodg.setBackgroundColor(Color.GREEN);
                        iducpit();

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '-') {
                    if (res4 == broj3 - broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        cetvrtiodg.setBackgroundColor(Color.GREEN);
                        iducpit(); //dalje pitanje

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '*') {
                    if (res4 == broj3 * broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        cetvrtiodg.setBackgroundColor(Color.GREEN);
                        iducpit();//dalje pitanje

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
                if (tocna_op == '/') {
                    if (res4 == broj3 / broj4) {
                        pitanje.setText("Tocan odgovor, idemo dalje");
                        pare.setText("Tvoj novac: " + novac);
                        iducepitanje.setVisibility(View.VISIBLE);
                        cetvrtiodg.setBackgroundColor(Color.GREEN);
                        iducpit();//dalje pitanje

                    } else {
                        pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                        endGame(0);
                        iducepitanje.setVisibility(View.GONE);
                    }
                }
            });
            broj_pitanja++;
        }


        /*-------------------------------------------------------------------------------------------------------*/

        else if(broj_pitanja<11) {

            broj5 = (int) (Math.random() * 35);
         broj6 = (int) (Math.random() * 4 + 1);

            if (tocna_op2 == '%') {
                tocna_operacija = " modularno ";
                tocanodg2 =(int) broj5 % broj6;
            } else if (tocna_op2 == 'p') {
                tocna_operacija = " potencirano ";
                tocanodg2 = (int) (Math.pow(broj5, broj6));
            } else if (tocna_op2 == '2') {
                tocna_operacija = " na kvadrat ";
                tocanodg2 = (int) (Math.pow(broj5, 2));
            } else {
                tocna_operacija = " korijen od ovog broja? ";
                tocanodg2 = (int) (Math.sqrt(broj5));
            }

            if (broj_pitanja == 6) {
                novac = 2000;
            }

            if (broj_pitanja == 7) {
                novac = 4000;
            }
            if (broj_pitanja == 8) {
                novac = 8000;
            }
            if (broj_pitanja == 9) {
                novac = 16000;
            }
            if (broj_pitanja == 10) {
                novac = 32000;
            }

        prviodg.setBackgroundColor(Color.parseColor("#6666FF"));
        drugiodg.setBackgroundColor(Color.parseColor("#6666FF"));
        treciodg.setBackgroundColor(Color.parseColor("#6666FF"));
        cetvrtiodg.setBackgroundColor(Color.parseColor("#6666FF"));

        if (tocna_op2=='2') {
            pitanje.setText("Koliko je " + (int) broj5 + tocna_operacija+"?");
        }
        else if(tocna_op2=='k') {
            pitanje.setText("Koliko je " + (int) broj5 + tocna_operacija+"?");
        }
        else {
            pitanje.setText("Koliko je " + (int) broj5 + tocna_operacija + broj6+"?");
        }

        //ponudivanje odgovora
        prviodg.setText(String.valueOf((tocanodg2 + rj_bliz[rjesenja[0]])));
        drugiodg.setText(String.valueOf((tocanodg2 + rj_bliz[rjesenja[1]])));
        treciodg.setText(String.valueOf((tocanodg2 + rj_bliz[rjesenja[2]])));
        cetvrtiodg.setText(String.valueOf((tocanodg2 + rj_bliz[rjesenja[3]])));

        iducepitanje.setVisibility(View.INVISIBLE);

        prviodg.setOnClickListener(v -> {   //ako je u prvom botunu odg
            res5 = Integer.parseInt(prviodg.getText().toString());
            if (tocna_op2 == '%') {
                if (res5 == broj5 % broj6) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    prviodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == '2') {
                if (res5 == (int) (Math.pow(broj5, 2))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    prviodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == 'p') {
                if (res5 == (int) (Math.pow(broj5, broj6))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    prviodg.setBackgroundColor(Color.GREEN);
                    iducpit();//dalje pitanje

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0); //gotovo
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == 'k') {
                if (res5== (int)(Math.sqrt(broj5))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    prviodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
        });
        drugiodg.setOnClickListener(v -> {  //ako je u drugom botunu odg
            res6 = Integer.parseInt(drugiodg.getText().toString());
            if (tocna_op2 == '%') {
                if (res6 == broj5 % broj6) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    drugiodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == '2') {
                if (res6 == (int) (Math.pow(broj5, 2))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    drugiodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == 'p') {
                if (res6 == (int) (Math.pow(broj5, broj6))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    drugiodg.setBackgroundColor(Color.GREEN);
                    iducpit();//dalje pitanje

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0); //gotovo
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == 'k') {
                if (res6 == (int)(Math.sqrt(broj5))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    drugiodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
        });

        treciodg.setOnClickListener(v -> { //ako je u trecem botunu odg
            res7 = Integer.parseInt((treciodg.getText().toString()));
            if (tocna_op2 == '%') {
                if (res7 == broj5 % broj6) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    treciodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == '2') {
                if (res7 == (int) (Math.pow(broj5, 2))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    treciodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == 'p') {
                if (res7 == (int) (Math.pow(broj5, broj6))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    treciodg.setBackgroundColor(Color.GREEN);
                    iducpit();//dalje pitanje

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0); //gotovo
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == 'k') {
                if (res7 == (int)(Math.sqrt(broj5))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    treciodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
        });
        cetvrtiodg.setOnClickListener(v -> { //ako je u cetvrtom botunu odg
            res8 = Integer.parseInt(cetvrtiodg.getText().toString());
            if (tocna_op2 == '%') {
                if (res8 == broj5 % broj6) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    cetvrtiodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == '2') {
                if (res8 == (int) (Math.pow(broj5, 2))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    cetvrtiodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == 'p') {
                if (res8 == (int) (Math.pow(broj5, broj6))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    cetvrtiodg.setBackgroundColor(Color.GREEN);
                    iducpit();//dalje pitanje

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0); //gotovo
                    iducepitanje.setVisibility(View.GONE);
                }
            }
            if (tocna_op2 == 'k') {
                if (res8 == (int)(Math.sqrt(broj5))) {
                    pitanje.setText("Tocan odgovor, idemo dalje");
                    pare.setText("Tvoj novac: " + novac);
                    iducepitanje.setVisibility(View.VISIBLE);
                    cetvrtiodg.setBackgroundColor(Color.GREEN);
                    iducpit();

                } else {
                    pitanje.setText("Netočan odgovor.  Ispali ste iz igre!");
                    endGame(0);
                    iducepitanje.setVisibility(View.GONE);
                }
            }
        });
        broj_pitanja++;
    }
        //-----------------------------------------
        else
    {
        endGame(0);
        return;
    }


    }
}






